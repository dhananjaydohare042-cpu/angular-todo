
# 📝 Angular ToDo App

This project is a **Todo List application built using Angular**.  
It allows users to add, manage, and remove tasks through a clean and interactive user interface.

The project demonstrates core **Angular development concepts** such as components, data binding, event handling, and application structure while building a practical productivity tool.

---

# 🚀 Features

- ➕ Add new tasks
- 📋 Display tasks in a dynamic list
- ✔️ Mark tasks as completed
- ❌ Delete tasks
- ⚡ Fast and responsive UI

---

# 🛠 Tech Stack

This project uses modern front-end technologies:

- **Angular** – Frontend framework
- **TypeScript** – Application logic
- **HTML5** – Structure and templates
- **CSS3** – Styling and layout
- **Node.js / npm** – Package management

---

# 📂 Project Structure

```
AngularToDoApp/
│
├── src/                 # Angular application source code
│   ├── app/             # Main Angular components and modules
│   ├── assets/          # Static assets
│   ├── index.html       # Main HTML file
│   └── styles.css       # Global styles
│
├── angular.json         # Angular project configuration
├── package.json         # Project dependencies
└── README.md            # Project documentation
```

---

# ⚙️ How the Application Works

1. The Angular application loads a **task input interface**.
2. Users can enter a new task and add it to the list.
3. Tasks are rendered dynamically using **Angular components and templates**.
4. Users can mark tasks as completed or remove them from the list.
5. Angular automatically updates the UI when the application state changes.

---

# ▶️ Run the Project Locally

### 1️⃣ Clone the repository

```
git clone https://github.com/nischalare/AngularToDoApp.git
```

### 2️⃣ Navigate to the project folder

```
cd AngularToDoApp
```

### 3️⃣ Install dependencies

```
npm install
```

### 4️⃣ Run the development server

```
ng serve
```

Then open your browser and go to:

```
http://localhost:4200
```

# Live Deployment on firebase at 
```https://angulartodolistapp-e6fd5.web.app/``` 

---

# 📚 Concepts Demonstrated

This project demonstrates:

- Angular component architecture
- TypeScript application structure
- Two-way data binding
- Event handling
- Dynamic UI rendering
- Angular project organization

---

# 📈 Possible Future Improvements

Potential enhancements include:

- 🗂 Task categories
- ⏱ Due date and reminders
- 💾 Local storage or database persistence
- 📱 Mobile responsive layout
- 🌙 Dark mode support

---

# 👨‍💻 Author

**Nischal Aremanda**

GitHub:  
https://github.com/nischalare

---

# 📜 License

This project is open source and available under the **MIT License**.
